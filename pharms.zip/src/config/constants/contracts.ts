export default {
  cake: {
    56: '0xF952Fc3ca7325Cc27D15885d37117676d25BfdA6',
    97: '0x7d10c42bcDC7A3628b4F25eA0aBc55cA82c110eC',
  },
  masterChef: {
    56: '0xe70E9185F5ea7Ba3C5d63705784D8563017f2E57',
    97: '0x907FB18da736F6A4EB54159ADd2a9CC568c2dAc5',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '0x58AbBb3c89750dDA42b65822042EbADb00f9Ef61',
  },
  lottery: {
    56: '',
    97: '',
  },
  lotteryNFT: {
    56: '',
    97: '',
  },
  mulltiCall: {
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0xC19831b355003A60093E3A37dbCA80C1e8605309',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '0xa2D2b501E6788158Da07Fa7e14DEe9F2C5a01054',
  },
}
