export default {
  cake: {
    56: '0xF952Fc3ca7325Cc27D15885d37117676d25BfdA6',
    97: '0x78855b0C2E34A622e7c20E68f2c658778d9888c7',
  },
  masterChef: {
    56: '0xe70E9185F5ea7Ba3C5d63705784D8563017f2E57',
    97: '0x0ec5eee040b9b3600dc1c0decaae50a89942e91b',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '0x58AbBb3c89750dDA42b65822042EbADb00f9Ef61',
  },
  lottery: {
    56: '',
    97: '0x8bf3c1ccf9dbce04ac8a6e3b4d0eadb1de7d7a0b',
  },
  lotteryNFT: {
    56: '',
    97: '0x4D9CfE75fB75aDb644C64908aF0216E6a15d1a84',
  },
  mulltiCall: {
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0xC19831b355003A60093E3A37dbCA80C1e8605309',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '0xa2D2b501E6788158Da07Fa7e14DEe9F2C5a01054',
  },
}
